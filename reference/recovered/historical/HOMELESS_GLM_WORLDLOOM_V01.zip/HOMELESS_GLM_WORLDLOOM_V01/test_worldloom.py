import random, unittest
from worldloom import World, VirtualPopulation, cell, express_address, read_address, turn_word, Route, MODELS

class WorldLoomTests(unittest.TestCase):
    def setUp(self):
        self.w = World()

    def test_global_coordinate_boundaries(self):
        for x,y in [(90,180),(-90,-180),(0,0),(37.4,-118.3),(-33,151),(49,36)]:
            self.assertEqual(cell(x,y), cell(x,y))
        self.assertNotEqual(cell(90,180),cell(-90,-180))
        self.assertEqual(cell(1,180), cell(1,-180))
        with self.assertRaises(ValueError): cell(91,0)

    def test_global_sampling(self):
        r = random.Random(7)
        seen = {cell(r.uniform(-90,90),r.uniform(-180,180),level=12).key() for _ in range(30000)}
        self.assertGreater(len(seen),29500)

    def test_address_decode_and_tampering(self):
        a=express_address("geo",{"lat":10.2,"lon":-25})
        self.assertEqual(read_address(a)["payload"]["lat"],10.2)
        self.assertEqual(self.w.resolve(a)["source"],"index-only")
        with self.assertRaises(ValueError):read_address(a[:-1]+('a' if a[-1]!='a' else 'b'))

    def test_all_models_contracts(self):
        self.assertEqual(len(MODELS),10)
        self.assertTrue(all(s.alphabet and s.verifier for s in MODELS.values()))

    def test_population_virtual_size_no_materialization(self):
        self.assertEqual(self.w.population.capacity,8_000_000_000)
        self.assertEqual(len(self.w.population.materialized),0)
        self.assertEqual(self.w.population.actor(7_999_999_999),self.w.population.actor(7_999_999_999))
        with self.assertRaises(IndexError): self.w.population.actor(8_000_000_000)

    def test_npc_local_decisions(self):
        p=self.w.population.materialize(900,"synthetic-hk")
        self.assertEqual(p["status"],"synthetic-active")
        a=self.w.population.choose(900,10)
        self.assertEqual(a,self.w.population.choose(900,10))
        self.assertEqual(self.w.population.choose(900,10,{"fatigue":10})["action"],"rest")

    def fixtures(self):
        for name,loc,bearing in [('la','Los Angeles',(0,90,90,180,180)),
                                  ('hk','Hong Kong',(100,190,190,280,280)),
                                  ('dxb','Dubai',(260,350,350,80,80)),
                                  ('other','Kharkiv',(0,0,90,0,90))]:
            self.w.register_route(Route(name,loc,bearing))

    def test_topology_rotation_invariance(self):
        self.assertEqual(turn_word([0,90,90,180]),turn_word([100,190,190,280]))

    def test_portal_modes_and_consents(self):
        self.fixtures()
        self.assertEqual(self.w.candidates('la'),['hk','dxb'])
        with self.assertRaises(PermissionError):self.w.portal('dark','la','hk','visit',consent=True)
        self.w.learn('dark','la')
        for mode in ('visit','overlay','braid'):
            e=self.w.portal('dark','la','hk',mode,consent=True)
            self.assertEqual(e['payload']['mode'],mode)
            self.assertFalse(e['payload']['physical_travel'])
        with self.assertRaises(PermissionError): self.w.portal('dark','la','hk','visit')
        with self.assertRaises(ValueError): self.w.portal('dark','la','other','visit',consent=True)

    def test_route_matches_not_real_world_evidence(self):
        self.fixtures()
        self.w.learn('dark','la')
        e=self.w.portal('dark','la','dxb','braid',consent=True)
        self.assertEqual(e['payload']['evidence'],'synthetic-topology')

    def test_design_coauthorship_permissions(self):
        p=self.w.propose_design('human:1','fictional-cafe',{'facade_palette':'gold'})
        with self.assertRaises(PermissionError):self.w.adopt(p,steward_consent=False)
        with self.assertRaises(ValueError):self.w.endorse('human:1',p)
        self.w.endorse('npc:10',p)
        with self.assertRaises(ValueError):self.w.endorse('npc:10',p)
        e=self.w.adopt(p,steward_consent=True)
        self.assertEqual(e['payload']['contributors'],['human:1','npc:10'])
        with self.assertRaises(ValueError):self.w.adopt(p,steward_consent=True)

    def test_reject_unsafe_untyped_edits(self):
        with self.assertRaises(ValueError):self.w.propose_design('a','b',{'edit_everything':True})

    def test_history_integrity_and_causality(self):
        self.w.emit('start',{'value':0})
        e=self.w.emit('next',{'value':1},['ev:0'])
        self.assertTrue(self.w.verify())
        e['payload']['value']=100
        self.assertFalse(self.w.verify())

    def test_asset_determinism_and_honest_provenance(self):
        a=self.w.asset(cell(23.3,43))
        self.assertEqual(a,self.w.asset(cell(23.3,43)))
        self.assertEqual(a['source'],'synthetic')
        self.assertIn('not-rendered-mesh',a['kind'])

    def test_queries_are_pure(self):
        self.fixtures()
        q=express_address('portal',{'route':'la'})
        count=len(self.w.ledger)
        self.assertEqual(self.w.resolve(q),self.w.resolve(q))
        self.assertEqual(count,len(self.w.ledger))

if __name__=='__main__':unittest.main()
