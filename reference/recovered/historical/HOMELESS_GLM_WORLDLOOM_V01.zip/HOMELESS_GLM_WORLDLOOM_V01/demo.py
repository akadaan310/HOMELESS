"""Run from the folder; yields a deterministic self-contained global research scenario."""
import json
from worldloom import World, cell, express_address, Route

w=World()
anchors=[('Los Angeles',34.05,-118.24),('Hong Kong',22.32,114.17),('Dubai',25.20,55.27),
         ('Kharkiv',49.99,36.23),('Nairobi',-1.29,36.82),('Sao Paulo',-23.55,-46.63),
         ('Sydney',-33.87,151.21),('Tokyo',35.67,139.65),('Reykjavik',64.14,-21.94)]
index={name:w.resolve(express_address('geo',{'lat':lat,'lon':lon,'level':16}))['cell'] for name,lat,lon in anchors}
# NOTE: these bearings are intentionally SYNTHETIC and not extracted from city streets.
for i,(name,_,_) in enumerate(anchors):
    initial=i*40
    bearings=tuple((initial+x)%360 for x in (0,90,90,180,180))
    w.register_route(Route(f"route-{i}",name,bearings,'synthetic'))

w.population.materialize(700,'Los Angeles',('explore','help','rest'))
w.population.materialize(1300,'Hong Kong',('observe','help'))
choices=[w.population.choose(700,t,{'fatigue':8 if t==5 else 0}) for t in range(6)]
w.learn('player:dark','route-0')
portal=w.portal('player:dark','route-0','route-1','braid',consent=True)
proposal=w.propose_design('player:dark','fictional-cafe',{'facade_palette':'terracotta','street_story':'three-doors'})
w.endorse('npc:700',proposal)
accepted=w.adopt(proposal,steward_consent=True)
print(json.dumps({'scope':'global index; synthetic topology, not real map ingestion',
'earth_cells':index,'virtual_capacity':w.population.capacity,
'active_npcs':len(w.population.materialized), 'sample_decisions':choices,
'matched_routes':w.candidates('route-0'),
'portal':portal['payload'], 'coauthorship':accepted['payload']['contributors'],
'event_count':len(w.ledger),'ledger_valid':w.verify(),'ledger_tip':w.ledger[-1]['hash']},indent=2))
