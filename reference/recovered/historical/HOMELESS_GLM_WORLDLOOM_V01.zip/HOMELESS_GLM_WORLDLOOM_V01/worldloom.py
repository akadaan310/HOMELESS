"""HOMELESS / World Loom 0.1: CPU-only domain-neutral generative world research kernel.

This demonstrator uses synthetic data. It provides worldwide coordinate addressing,
NOT real-world map ingestion, live weather, rendered 3-D or 8B independently ticking NPCs.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any
import base64, hashlib, json, math


def canonical(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")


def digest(obj: Any) -> str:
    return hashlib.sha256(canonical(obj)).hexdigest()


@dataclass(frozen=True)
class ModelSpec:
    kind: str
    alphabet: str
    generator: str
    verifier: str
    materialization: str


MODELS: dict[str, ModelSpec] = {
    "actor": ModelSpec("actor", "needs|goals|relations|acts", "bounded preference policy", "legal transition and trace", "active/cohort/virtual"),
    "activity": ModelSpec("activity", "actions × time × place", "schedule grammar", "resources and time guards", "event"),
    "event": ModelSpec("event", "cause|effect|witness", "typed causal transducer", "acyclic cause references", "ledger"),
    "mission": ModelSpec("mission", "goal|constraint|outcome", "goal automaton", "authorized fictional outcomes", "storylet"),
    "spatial": ModelSpec("spatial", "turns × graph × chart", "path grammar", "source and geometric certificates", "tiles/routes"),
    "portal": ModelSpec("portal", "source|target|mode", "chart correspondence", "learned, matching, consent", "view/instance"),
    "society": ModelSpec("society", "relations|groups|trust", "relationship transition", "agency and privacy rules", "cohort"),
    "asset": ModelSpec("asset", "primitive|material|rule", "seeded procedural recipe", "budget and license", "mesh requested separately"),
    "language": ModelSpec("language", "act|lexicon|gloss|usage", "G×I constrained text plan", "admissibility and grounding", "dialogue"),
    "governance": ModelSpec("governance", "proposal|vote|rights", "explicit authorization", "immutable provenance and consent", "coauthored change"),
}


@dataclass(frozen=True)
class GeoCell:
    level: int
    row: int
    column: int

    def key(self) -> str:
        return f"earth/{self.level}/{self.row}/{self.column}"


def cell(lat: float, lon: float, level: int = 10) -> GeoCell:
    """Global indexed domain; not equal-area and not a real geographic dataset."""
    if not (math.isfinite(lat) and math.isfinite(lon) and -90 <= lat <= 90 and -180 <= lon <= 180):
        raise ValueError("latitude/longitude out of range")
    if not (0 <= level <= 24):
        raise ValueError("level outside declared index")
    if lon == 180:
        lon = -180  # same meridian; canonicalize antimeridian
    scale = 1 << level
    # Half-open grid, with ±90/180 boundaries clamped to the final cell.
    return GeoCell(level, min(scale-1, int((lat+90)/180*scale)),
                   min(scale-1, int((lon+180)/360*scale)))


def express_address(kind: str, payload: dict[str, Any]) -> str:
    """A self-describing, decodable program ADDRESS, not an O(1) execution claim."""
    if kind not in ("geo", "actor", "asset", "model", "portal"):
        raise ValueError("unknown address grammar")
    data = {"version": 1, "kind": kind, "payload": payload}
    raw = canonical(data)
    encoded = base64.urlsafe_b64encode(raw).decode().rstrip("=")
    return f"wgm:v1:{encoded}.{hashlib.sha256(raw).hexdigest()[:16]}"


def read_address(address: str) -> dict[str, Any]:
    if not address.startswith("wgm:v1:") or "." not in address:
        raise ValueError("invalid grammar")
    body, proof = address[7:].rsplit(".", 1)
    try:
        raw = base64.urlsafe_b64decode(body + "=" * ((-len(body)) % 4))
        data = json.loads(raw)
    except (ValueError, UnicodeDecodeError) as exc:
        raise ValueError("invalid address encoding") from exc
    if digest(data)[:16] != proof or canonical(data) != raw:
        raise ValueError("address checksum or canonicalization failure")
    if data.get("version") != 1 or data.get("kind") not in ("geo", "actor", "asset", "model", "portal"):
        raise ValueError("invalid address program")
    if not isinstance(data.get("payload"), dict):
        raise ValueError("invalid program payload")
    return data


class VirtualPopulation:
    """Random-access synthetic IDs, not a demographic reconstruction of humanity."""
    def __init__(self, capacity: int = 8_000_000_000, seed: str = "homeless-v0"):
        if capacity < 1:
            raise ValueError("capacity must be positive")
        self.capacity = capacity
        self.seed = seed
        self.materialized: dict[int, dict[str, Any]] = {}

    def actor(self, ordinal: int) -> dict[str, Any]:
        if not isinstance(ordinal, int) or not 0 <= ordinal < self.capacity:
            raise IndexError("actor outside virtual address space")
        if ordinal in self.materialized:
            return dict(self.materialized[ordinal])
        # Deterministic but deliberately NOT distributed as real humans are.
        h = hashlib.sha256(f"{self.seed}:{ordinal}".encode()).digest()
        return {"id": f"virtual:{ordinal}", "personality_seed": int.from_bytes(h[:8], "big"),
                "status": "synthetic-unrealized", "source": "procedural"}

    def materialize(self, ordinal: int, locale: str, goals: tuple[str, ...] = ("explore", "help", "rest")) -> dict[str, Any]:
        actor = self.actor(ordinal)
        actor.update(locale=locale, goals=list(goals), status="synthetic-active", memory=[])
        self.materialized[ordinal] = actor
        return dict(actor)

    def choose(self, ordinal: int, epoch: int, context: dict[str, Any] | None = None) -> dict[str, Any]:
        person = self.materialized.get(ordinal)
        if person is None:
            raise ValueError("actor not materialized")
        context = context or {}
        needs_rest = context.get("fatigue", 0) >= 7
        if needs_rest:
            action = "rest"
        else:
            goals = person["goals"]
            selection = int(digest([person["personality_seed"], epoch, context])[:10], 16)
            action = goals[selection % len(goals)]
        return {"actor": person["id"], "tick": epoch, "action": action,
                "reason": "fatigue_guard" if needs_rest else "seeded_goal_policy"}


def turn_word(bearings: list[int | float]) -> tuple[str, ...]:
    """Rotation-invariant symbolic turn word, quantized in 45-degree steps."""
    if len(bearings) < 2 or any(not math.isfinite(x) for x in bearings):
        raise ValueError("need finite bearings")
    out = []
    for a, b in zip(bearings, bearings[1:]):
        delta = ((b - a + 180) % 360) - 180
        if abs(delta) < 22.5:
            out.append("S")
        elif abs(delta) > 157.5:
            out.append("U")
        elif delta > 0:
            out.append("R")
        else:
            out.append("L")
    return tuple(out)


@dataclass(frozen=True)
class Route:
    id: str
    locality: str
    bearings: tuple[int | float, ...]
    source: str = "synthetic"

    def signature(self) -> tuple[str, ...]:
        return turn_word(list(self.bearings))


@dataclass
class World:
    population: VirtualPopulation = field(default_factory=VirtualPopulation)
    ledger: list[dict[str, Any]] = field(default_factory=list)
    routes: dict[str, Route] = field(default_factory=dict)
    knowledge: dict[str, set[tuple[str, ...]]] = field(default_factory=dict)
    proposals: dict[str, dict[str, Any]] = field(default_factory=dict)
    revisions: dict[str, dict[str, Any]] = field(default_factory=dict)

    def emit(self, kind: str, payload: dict[str, Any], parents: list[str] | None = None) -> dict[str, Any]:
        parents = parents or []
        known = {e["id"] for e in self.ledger}
        if any(p not in known for p in parents):
            raise ValueError("unknown causal parent")
        previous = self.ledger[-1]["hash"] if self.ledger else "0"*64
        base = {"index": len(self.ledger), "kind": kind, "payload": payload, "parents": parents, "prev": previous}
        event = {**base, "id": f"ev:{len(self.ledger)}", "hash": digest(base)}
        self.ledger.append(event)
        return event

    def verify(self) -> bool:
        prev, seen = "0"*64, set()
        for i, e in enumerate(self.ledger):
            base = {k:e[k] for k in ("index", "kind", "payload", "parents", "prev")}
            if (e["index"] != i or e["id"] != f"ev:{i}" or e["prev"] != prev or
                e["hash"] != digest(base) or any(p not in seen for p in e["parents"])):
                return False
            seen.add(e["id"])
            prev = e["hash"]
        return True

    def register_route(self, route: Route) -> None:
        if route.id in self.routes:
            raise ValueError("duplicate route")
        if len(route.bearings) < 3 or route.source not in ("synthetic", "verified-map"):
            raise ValueError("route needs at least two turns and a provenance class")
        route.signature()
        self.routes[route.id] = route
        self.emit("route.register", {"id": route.id, "signature": route.signature(), "source": route.source})

    def candidates(self, source_id: str) -> list[str]:
        src = self.routes[source_id]
        return [r.id for r in self.routes.values() if r.id != source_id and
                r.locality != src.locality and r.signature() == src.signature()]

    def learn(self, actor: str, source_id: str) -> dict[str, Any]:
        sig = self.routes[source_id].signature()
        self.knowledge.setdefault(actor, set()).add(sig)
        return self.emit("portal.learn", {"actor": actor, "route": source_id, "signature": sig})

    def portal(self, actor: str, source_id: str, target_id: str, mode: str, *, consent: bool = False) -> dict[str, Any]:
        if mode not in ("visit", "overlay", "braid"):
            raise ValueError("unknown portal mode")
        if not consent:
            raise PermissionError("explicit player consent required")
        if target_id not in self.candidates(source_id):
            raise ValueError("no certified structural correspondence")
        if self.routes[source_id].signature() not in self.knowledge.get(actor, set()):
            raise PermissionError("skill not learned")
        src, target = self.routes[source_id], self.routes[target_id]
        reality = "fictional-world-transformation" if mode in ("visit", "braid") else "fictional-scene-projection"
        if src.source == "verified-map" and target.source == "verified-map":
            evidence = "map-verified-topology-only"
        else:
            evidence = "synthetic-topology"
        return self.emit("portal.resolve", {"actor": actor, "from": source_id, "to": target_id,
                                            "mode": mode, "reality": reality, "evidence": evidence,
                                            "physical_travel": False})

    def propose_design(self, author: str, place: str, patch: dict[str, Any]) -> str:
        allowed = {"shop_name", "facade_palette", "public_mural", "street_story"}
        if not patch or not set(patch).issubset(allowed):
            raise ValueError("non-admissible design patch")
        if len(canonical(patch)) > 2048:
            raise ValueError("proposal too large")
        proposal = self.emit("design.propose", {"author": author, "place": place, "patch": patch})
        self.proposals[proposal["id"]] = {"author": author, "place": place, "patch": patch, "endorsements": set()}
        return proposal["id"]

    def endorse(self, actor: str, proposal_id: str) -> dict[str, Any]:
        p = self.proposals[proposal_id]
        if actor == p["author"]:
            raise ValueError("distinct contributor required")
        if actor in p["endorsements"]:
            raise ValueError("already endorsed")
        p["endorsements"].add(actor)
        return self.emit("design.endorse", {"actor": actor, "proposal": proposal_id}, [proposal_id])

    def adopt(self, proposal_id: str, *, steward_consent: bool) -> dict[str, Any]:
        if not steward_consent:
            raise PermissionError("steward approval required")
        p = self.proposals[proposal_id]
        if not p["endorsements"]:
            raise ValueError("requires independent collaboration")
        if proposal_id in self.revisions:
            raise ValueError("already adopted")
        authors = sorted({p["author"]} | p["endorsements"])
        ev = self.emit("design.adopt", {"place":p["place"], "patch":p["patch"],
                                       "contributors":authors, "authorship": "simulated-creative-provenance"}, [proposal_id])
        self.revisions[proposal_id] = ev
        return ev

    def asset(self, geocell: GeoCell, archetype: str = "streetscape") -> dict[str, Any]:
        if archetype not in ("streetscape", "cafe", "courtyard"):
            raise ValueError("unknown geometry archetype")
        seed = digest([geocell.key(), archetype])
        return {"kind": "procedural-3d-recipe-not-rendered-mesh", "cell": geocell.key(),
                "archetype": archetype, "palette": ["sand", "slate", "terracotta"][int(seed[0], 16)%3],
                "geometry": [{"primitive": "box", "scale": [2, 4, 3]},
                             {"primitive": "plane", "scale": [12, 1, 12]}],
                "seed": seed[:16], "source": "synthetic"}

    def resolve(self, address: str) -> dict[str, Any]:
        req = read_address(address)
        p = req["payload"]
        if req["kind"] == "geo":
            return {"cell": cell(p["lat"], p["lon"], p.get("level", 10)).key(), "source": "index-only"}
        if req["kind"] == "actor":
            return self.population.actor(p["ordinal"])
        if req["kind"] == "asset":
            return self.asset(cell(p["lat"], p["lon"]), p.get("archetype", "streetscape"))
        if req["kind"] == "model":
            s = MODELS[p["name"]]
            return s.__dict__.copy()
        if req["kind"] == "portal":
            return {"signature": self.routes[p["route"]].signature(),
                    "candidates": self.candidates(p["route"]), "mutation": False}
        raise ValueError("unreachable")
