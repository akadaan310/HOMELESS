# HOMELESS / World Loom 0.1

**CPU-only demonstrator + world-wide architecture specification.** Domain-independent *Generative World Model*, using Gaming Language Models and Language Gaming Models as engine constructs. Authorship direction: Abed Kadan / ChatGPT 7u.

```
python -m unittest test_worldloom -v
python demo.py
```

Python 3.11+, standard library; no dependencies or network needed.

Files:
- `WORLD_LOOM_FOUNDATION.md` — full scope, definitions, architecture, data adapters, research questions and launch gates.
- `worldloom.py` — ten model descriptions; global cells; decodable computational addresses; synthetic 8B actor ID capacity; bounded NPC policy; rotation-invariant turn grammar; 3 fictional portal modes; player/NPC design proposals; event hash-chain; tiny parametric 3D **recipe**, not rendered art.
- `test_worldloom.py` — 14 unit tests, including 30,000 worldwide random coordinate probes.
- `demo.py` — nine global geographic anchor points, synthetic matching routes across them, NPC choices, fictional portal, coauthored scene change, ledger integrity.
- `test-results.txt`, `demo-result.json` — captured output from current environment.

**Hard limitation**: the current demo's sampled global coordinates ARE NOT full map data; geographic correspondence signatures are SYNTHETIC, not actual road matches. The virtual population is an address space and its synthetic actors are not full independently acting minds. No weather API, real terrain, photorealistic mesh renderer or multiplayer server is shipped. The address is descriptive and executable by a resolver, but not a constant-time guarantee for arbitrary computation. This is not a ready-to-launch product.

Read the license and uncertainty terms for all future data providers, particularly OSM/Overture map data, weather APIs, demographic rasters and photogrammetry tiles. The world's fictional authorship registry must never be mistaken for property rights to real landmarks.
